let http404Error = (404, "Not Found")
// http404Error is of type (Int, String), and equals (404, "Not Found")
