var welcomeMessage: String
